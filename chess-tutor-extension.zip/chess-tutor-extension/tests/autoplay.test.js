/* Tests for auto-play and for the "instant" search rules.
   Run with:  node tests/autoplay.test.js
   The promises pinned down here are the ones the panel makes to the user:
     - Max time 0 (and auto-play speed 0) means instant: the engine's first complete result is the answer, and
       the search is stopped there instead of being waited out
     - a normal search reports the deepest depth that holds every line, so arrows never mix iterations
     - a forced position (fewer legal moves than MultiPV) still answers immediately
     - a search is never sent with neither a depth nor a time
     - auto-play speed is a rhythm, not a second delay: a slow search is not slowed down twice
     - the play level decides which of the engine's lines gets played (the ELO deviation rule)
*/
'use strict';
const L = require('../lib.js');

let checks = 0, failures = 0;
function ok(cond, msg) {
  checks++;
  if (!cond) { failures++; console.error('FAIL: ' + msg); }
}
function eq(a, b, msg) { ok(a === b, msg + ' (got ' + JSON.stringify(a) + ', want ' + JSON.stringify(b) + ')'); }

// ---- 1. a normal search reports the deepest depth that has every line
const dump = {
  1: { 1: { depth: 1, multipv: 1, move: 'e2e4' } },
  2: { 1: { depth: 2, multipv: 1, move: 'e2e4' } },
  3: { 1: { depth: 3, multipv: 1, move: 'e2e4' }, 2: { depth: 3, multipv: 2, move: 'd2d4' } },
  4: { 1: { depth: 4, multipv: 1, move: 'g1f3' } }
};
// depth 3 is the deepest one carrying the full set (both lines); the lone depth-4 line is a half-filled
// iteration, so reporting depth 3 keeps all reported lines from the same depth
eq(L.bestDepth(dump), 3, 'the deepest depth holding every line wins over a deeper half-filled one');
eq(L.bestDepth({}), null, 'no lines at all -> no depth');
eq(L.bestDepth({ 1: {}, 2: {} }), null, 'empty depths -> no depth');

// ---- 2. MultiPV: the answer comes from one depth only - the deepest one holding the full set requested
const mpv3 = {
  1: { 1: { move: 'e2e4' }, 2: { move: 'd2d4' }, 3: { move: 'g1f3' } },
  2: { 1: { move: 'e2e4' }, 2: { move: 'd2d4' }, 3: { move: 'g1f3' } },
  3: { 1: { move: 'e2e4' }, 2: { move: 'd2d4' } }        // depth 3 is still being filled in
};
eq(L.bestDepth(mpv3), 2, 'the deepest depth with all three lines is reported, not the half-filled one');
eq(L.firstDepth(mpv3, 3), 1, 'the first complete MultiPV set is depth 1');
eq(L.firstDepth(mpv3, 5), null, 'a depth with fewer lines than asked for is not "complete"');

// ---- 3. instant: the first complete result is the answer, no waiting for the search to finish
eq(L.instantDepth(mpv3, 3), 1, 'instant takes the first full set and never waits for a deeper one');
eq(L.instantDepth({ 1: { 1: { move: 'a' } }, 2: { 1: { move: 'b' } } }, 2), 1,
  'instant takes the depth the engine has moved past when MultiPV cannot be satisfied');
eq(L.instantDepth({ 1: { 1: { move: 'e2e4' } } }, 2), null, 'one lone depth is not an answer yet when more lines were asked for');

// ---- 4. forced position: fewer legal moves than MultiPV, so the depth below the newest one is the answer
const forced = {
  1: { 1: { move: 'h7h8q' }, 2: { move: 'h7g8q' } },      // only two moves exist, MultiPV asked for five
  2: { 1: { move: 'h7h8q' }, 2: { move: 'h7g8q' } }
};
eq(L.instantDepth(forced, 5), 1, 'a depth the engine has already moved past is as complete as it will get');
eq(L.instantDepth({ 1: { 1: { move: 'h7h8q' } } }, 5), null, 'still waiting on the very first depth');

// ---- 5. what to ask the engine for
const base = { depth: 7, time: 8, autoplay: false, speed: 0, safetyMs: 2500 };
let lim = L.searchLimits(base);
eq(lim.depth, 7, 'level preset depth is kept');
eq(lim.timeMs, 8000, 'max time becomes the movetime cap');
eq(lim.eager, false, 'a normal search waits for the engine to finish');

lim = L.searchLimits(Object.assign({}, base, { time: 0 }));
eq(lim.timeMs, 0, 'max time 0 sends no movetime at all');
eq(lim.eager, true, 'max time 0 is instant: first result, then stop');
ok(L.goCommand(lim).indexOf('movetime') < 0, 'instant does not ask the engine to sit on a clock');

lim = L.searchLimits(Object.assign({}, base, { autoplay: true, speed: 0 }));
eq(lim.eager, true, 'auto-play speed 0 plays as soon as the engine has a move, whatever Max time says');

lim = L.searchLimits(Object.assign({}, base, { autoplay: true, speed: 0.3 }));
eq(lim.timeMs, 300, 'auto-play speed caps the search at that many seconds');
eq(lim.eager, false, 'a paced search still waits for its own result');
lim = L.searchLimits(Object.assign({}, base, { autoplay: true, speed: 3, time: 0.5 }));
eq(lim.timeMs, 500, 'Max time stays the upper bound when it is smaller than the play speed');
lim = L.searchLimits(Object.assign({}, base, { autoplay: true, speed: 5, time: 0 }));
eq(lim.eager, true, 'Max time 0 wins over a slower play speed: never wait on a search when told to be instant');

// ---- 6. never a bare "go": a search with no depth limit and no time cap would run forever
lim = L.searchLimits(Object.assign({}, base, { depth: 0, time: 0 }));
ok(lim.depth || lim.timeMs, 'no depth limit + no time cap still gets a safety cap');
eq(lim.timeMs, 2500, 'the safety cap is used as the movetime');
for (const opt of [
  { depth: 0, time: 0 }, { depth: 0, time: 60 }, { depth: 24, time: 0 },
  { depth: 0, time: 0, autoplay: true, speed: 0 }, { depth: 0, time: 0, autoplay: true, speed: 2 }
]) {
  const l = L.searchLimits(opt), go = L.goCommand(l);
  ok(/^go (depth \d+|movetime \d+)/.test(go) || /^go depth \d+ movetime \d+$/.test(go),
    'go command always carries a limit: ' + JSON.stringify([opt, go]));
}
eq(L.goCommand({ depth: 12, timeMs: 0 }), 'go depth 12', 'depth-only search');
eq(L.goCommand({ depth: 0, timeMs: 250 }), 'go movetime 250', 'time-only search');

// ---- 7. auto-play speed is a rhythm, not a second delay
eq(L.paceWait(0, 0), 0, 'speed 0 = no wait at all');
eq(L.paceWait(0, 5000), 0, 'speed 0 = no wait even after a long search');
eq(L.paceWait(1000, 0), 1000, 'a move with a 1s rhythm waits a second when the engine was instant');
eq(L.paceWait(1000, 600), 400, 'the wait is measured from when the board was first read');
eq(L.paceWait(1000, 1000), 0, 'a search that already took the rhythm gets no extra wait');
eq(L.paceWait(1000, 5000), 0, 'a slow search is never slowed down further');

// ---- 8. which move auto-play plays at the chosen level
const lines = [{ move: 'e2e4' }, { move: 'd2d4' }, { move: 'g1f3' }];
const moves = lines.map(l => l.move);
eq(L.eloMove('e2e4', moves, 1200, () => 0.99), 'e2e4', 'an accurate roll plays the engine move');
eq(L.eloMove('e2e4', moves, 1200, () => 0.01), moves[0], 'a slip still plays one of the engine lines');
ok(moves.includes(L.eloMove('e2e4', moves, 400, () => 0.5)), 'the low-level slip picks a candidate line');
eq(L.eloMove('e2e4', moves, 3200, () => 0.001), 'e2e4', 'full engine strength never slips');
eq(L.eloMove('e2e4', moves, 2000, () => 0), 'e2e4', '2000+ has no error rate in the table');
eq(L.eloMove('e2e4', [], 400, () => 0), 'e2e4', 'no candidates -> the engine move');
eq(L.eloMove('e2e4', [null, undefined], 400, () => 0), 'e2e4', 'junk candidates are ignored');
// the whole rule, end to end: an instant answer from depth 1 feeds the level pick exactly like a finished search
const instantLines = Object.keys(mpv3[L.instantDepth(mpv3, 3)]).map(k => mpv3[1][k]);
eq(instantLines.length, 3, 'instant answer carries every line of that depth');
ok(instantLines.map(l => l.move).includes(L.eloMove(instantLines[0].move, instantLines.map(l => l.move), 800, () => 0.5)),
  'the level pick works on an instant answer too');

console.log((failures ? 'FAILED ' : 'OK ') + checks + ' checks, ' + failures + ' failures');
process.exit(failures ? 1 : 0);
